#!/bin/bash

docker run --rm --name alerts_server -p 9001:9001 quay.io/chronosphereiotest/interview-alerts-engine:v2 ${@}